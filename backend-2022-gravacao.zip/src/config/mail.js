const configMail = {
  host: "smtp.gmail.com",
  port: 465,
  secure: true,
  auth: {
    user: "naoresponda.acompnhatcc2022@gmail.com",
    pass: "ikscuqhgtosmiqof"
  },
  default: {
    from: "no-reply <noreply@acompanhatcc.com.br>"
  }
};

module.exports = configMail;
