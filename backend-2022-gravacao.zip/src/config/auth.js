module.exports = {
  jwt: {
    secret: "bfd9475961bf6dac456ec44fe2349e84",
    expiresIn: "1d"
  }
};

/**
 * aplicacao: md5.cz
 * chave:tccGravacao-GrazianiZanfolin
 * hash: bfd9475961bf6dac456ec44fe2349e84
 */
